package db.frontend.frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
