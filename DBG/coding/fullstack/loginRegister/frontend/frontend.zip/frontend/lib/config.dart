// backend routes
final url = 'http://192.168.1.162:3009/';
final regUser = url + "regUser";
final regEvent = url + "regEvent";
final login = url + 'login';
final createEvent = url + 'createEvent';
final getEventList = url + 'getEventList';
final deleteEvent = url + 'deleteEvent';
final events = url + 'events';